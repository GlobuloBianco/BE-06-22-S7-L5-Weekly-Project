package it.W7L5WP.models.proxy;

public class SondaHttpProxy implements SondaProxy {
    private String url;

    public SondaHttpProxy(String url) {
        this.url = url;
    }

    @Override
    public void allerta(int idSonda, double latitudine, double longitudine, int livelloFumo) {
        // Invio dell'allarme tramite HTTP
    	
        String urlPath = String.format("%s/alarm?idsonda=%d&lat=%f&lon=%f&smokelevel=%d", url, idSonda, latitudine, longitudine, livelloFumo);
        System.out.println(urlPath);
	    System.out.println("---------------------------------------");
    }
}
