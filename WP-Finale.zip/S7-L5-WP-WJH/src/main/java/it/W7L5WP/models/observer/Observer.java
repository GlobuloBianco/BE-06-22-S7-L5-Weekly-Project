package it.W7L5WP.models.observer;

import it.W7L5WP.models.Sonda;

public interface Observer {
	   public void aggiorna(Sonda sonda);
}
