package it.W7L5WP.models.observer;


public interface Subject {
    public void aggiungiObserver(Observer observer);
    public void rimuoviObserver(Observer observer);
    public void notificaObservers();
}
