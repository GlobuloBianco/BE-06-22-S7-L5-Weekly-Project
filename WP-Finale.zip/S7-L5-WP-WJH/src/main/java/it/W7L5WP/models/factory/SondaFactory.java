package it.W7L5WP.models.factory;

import it.W7L5WP.models.Sonda;
import it.W7L5WP.models.proxy.SondaProxy;

public class SondaFactory {
	public static Sonda createSonda(int id, double latitudine, double longitudine, SondaProxy proxy) {
		return new Sonda(id, latitudine, longitudine, proxy);
	}
}