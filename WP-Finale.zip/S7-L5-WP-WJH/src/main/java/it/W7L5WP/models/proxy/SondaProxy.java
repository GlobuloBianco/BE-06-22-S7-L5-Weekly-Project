package it.W7L5WP.models.proxy;

public interface SondaProxy {
    void allerta(int idSonda, double latitudine, double longitudine, int livelloFumo);
}
