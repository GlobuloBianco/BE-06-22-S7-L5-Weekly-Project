package it.W7L5WP.models;

import java.util.ArrayList;
import java.util.List;

import it.W7L5WP.models.observer.Observer;
import it.W7L5WP.models.observer.Subject;
import it.W7L5WP.models.proxy.SondaProxy;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
public class Sonda implements Subject {
    private int id;
    private double latitudine;
    private double longitudine;
    private int livelloFumo;
    private List<Observer> observers = new ArrayList<>();
    private SondaProxy proxy;
    
    //constructor
    public Sonda(int id, double latitudine, double longitudine, SondaProxy proxy) {
        this.id = id;
        this.latitudine = latitudine;
        this.longitudine = longitudine;
        this.livelloFumo = 0;
        this.proxy = proxy;
    }
    
    public void setLivelloFumo(Integer livelloFumo) {
        this.livelloFumo = livelloFumo;
        if (livelloFumo > 5) {
        	//test proxy
        	//proxy.allerta(id, latitudine, longitudine, livelloFumo);
        	
        	//notifica se supera i 5 di gravita
        	notificaObservers();
        }
    }

	@Override
	public void aggiungiObserver(Observer observer) {
		observers.add(observer);
	}

	@Override
	public void rimuoviObserver(Observer observer) {
		observers.remove(observer);
	}

	@Override
	public void notificaObservers() {
        for (Observer observer : observers) {
            observer.aggiorna(this);
        }
	}
}
