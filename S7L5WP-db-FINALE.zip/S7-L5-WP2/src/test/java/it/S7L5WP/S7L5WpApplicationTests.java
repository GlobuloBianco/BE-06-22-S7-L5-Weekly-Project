package it.S7L5WP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S7L5WpApplicationTests {

	@Test
	void contextLoads() {
	}

}
