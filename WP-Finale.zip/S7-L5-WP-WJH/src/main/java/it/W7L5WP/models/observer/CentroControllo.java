package it.W7L5WP.models.observer;

import it.W7L5WP.models.Sonda;
import it.W7L5WP.models.proxy.SondaProxy;

public class CentroControllo implements Observer {
    private SondaProxy proxy;

    public CentroControllo(SondaProxy proxy) {
        this.proxy = proxy;
    }

    @Override
    public void aggiorna(Sonda sonda) {
        // Invio dell'allarme tramite il proxy
        proxy.allerta(sonda.getId(), sonda.getLatitudine(), sonda.getLongitudine(), sonda.getLivelloFumo());
    }
}