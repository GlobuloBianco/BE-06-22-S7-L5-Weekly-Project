package it.W7L5WP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import it.W7L5WP.models.Sonda;
import it.W7L5WP.models.factory.SondaFactory;
import it.W7L5WP.models.observer.CentroControllo;
import it.W7L5WP.models.proxy.SondaHttpProxy;
import it.W7L5WP.models.proxy.SondaProxy;

@SpringBootApplication
public class S7L5WpWjhApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(S7L5WpWjhApplication.class, args);
		start();
	}
	 //---------------------------------------------------//

		//--[Switch-Avvio]--//
	static boolean crea = true;
	
	
	//---------------------------//
	private static void start() {
		if (crea) { crea(); }

	}
	
	// Creazione
	private static void crea() {
		
		SondaProxy proxy = new SondaHttpProxy("http://host/alarm");
		 
	    CentroControllo centroControllo = new CentroControllo(proxy);
	    
		//creazioni
	    Sonda s1 = SondaFactory.createSonda(1, 45.123, 7.456, proxy);
	    Sonda s2 = SondaFactory.createSonda(2, 46.789, 8.012, proxy);
	    Sonda s3 = SondaFactory.createSonda(3, 47.321, 9.876, proxy);

	    // Registra il centro di controllo come osservatore della sonda
	    s1.aggiungiObserver(centroControllo);
	    s2.aggiungiObserver(centroControllo);
	    s3.aggiungiObserver(centroControllo);
	    
    	System.out.println("\n l'implementazione avrebbe inviato l'HTTP seguente: \n");
    	
	    	s1.setLivelloFumo(6);
	    	s2.setLivelloFumo(3); // non viene fatto il console log essendo < 5
	    	s3.setLivelloFumo(10);
	    	s2.setLivelloFumo(8);
	    //uscita dal centro di controllo
	    s1.rimuoviObserver(centroControllo);
	    
	    //test dopo rimozione dal centro controllo (non dovrebbe stampare nulla)
	    s1.setLivelloFumo(10);
	    s2.setLivelloFumo(3);
	    s3.setLivelloFumo(5);
	}

}
