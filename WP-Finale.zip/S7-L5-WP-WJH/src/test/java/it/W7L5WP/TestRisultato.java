package it.W7L5WP;


import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import it.W7L5WP.models.Sonda;
import it.W7L5WP.models.observer.Observer;
import it.W7L5WP.models.proxy.SondaHttpProxy;
import it.W7L5WP.models.proxy.SondaProxy;

@SpringBootTest
public class TestRisultato {
	SondaProxy proxy = new SondaHttpProxy("http://host/alarm");
	@Test
	public void testRisultato() throws Exception {

		Sonda sonda = new Sonda(1, 45.123, 7.456, proxy);
		//test verifica risultato del lvl
        sonda.setLivelloFumo(6);
        assertEquals(6, sonda.getLivelloFumo());
        
        sonda.setLivelloFumo(3);
        assertEquals(3, sonda.getLivelloFumo());
        
        sonda.setLivelloFumo(5);
        assertEquals(5, sonda.getLivelloFumo());
	}
	
    @Test
    public void testAggiungiObserver() {
        Sonda sonda = new Sonda(1, 45.123, 7.456, proxy);
        Observer observer = mock(Observer.class);
        //test verifica aggiunta nell'observer
        sonda.aggiungiObserver(observer);
        assertEquals(1, sonda.getObservers().size());
    }
    
    @Test
    public void testRimuoviObserver() {
        Sonda sonda = new Sonda(1, 45.123, 7.456, proxy);
        Observer observer = mock(Observer.class);
        //test verifica rimozione
        sonda.aggiungiObserver(observer);
        assertEquals(1, sonda.getObservers().size());
    } 
}
